function avg = mean_image(images)
% EIGEN_FACES Computer the mean (average) image
% Matrix of Images -> Image

avg = mean(images);
    